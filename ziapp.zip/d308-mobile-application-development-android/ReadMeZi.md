# READ ME FILE FOR D308

## Title
Vac Track

## Purpose
The purpose of this app is to allow users to track vacations and any excursions associated with them in an all in one app.

## Directions and Rubric

To use the app, simply launch the app. You will be taken into the home page, here you will see two buttons: Add Vacation and i. The i button will give a simple overview of the app and the features it has.

To add a vacation, tap "Add Vacation". You will be taken to a new activity where you will see 4 fields and 1 switch. Here you will fill in the respective fields and select whether you want to be alerted on the dates. Then press "Submit", you will be taken back to the home page where you will see the vacation you entered has now populated the list.

To delete a vacation or share a vacation, you must enter select mode. To do this, long press any vacation and you will see the buttons at the bottom change and a indicator that you are in select mode. Here you can select all the vacations you want to share or delete then press the respective "Share Vacation" or "Remove Vacation". Alternatively, to exit select mode, press "Exit Select Mode".

To edit a vacation, tap the vacation you wish to edit. You will be taken to a new activity where you will see two tabs, "Vacation Details" and "Excursions". You will also see two buttons "Add Excursion" and "Save". To edit the vacation, tap the tab for "Vacation Details". The tab will expand with the vacation details where you can change them. To save your changes, tap "Save".

To add an excursion, you must be on an "Edit Vacation" activity of the vacation you want to add an excursion to. Tap "Add Excursion", then you will be taken to a new activity where you can fill out two fields and switch. Once complete, tap "Submit" to save your excursion.

To delete an excursion, the process is the same as a vacation. Long press any excursion and you will enter select mode. Here you can select all the excursions you want to delete and press "Remove Excursion". Alternatively, you can exit select mode with the "Exit Select Mode" button.

To edit an excursion, tap the excursion you want to edit. You will be taken to a new activity where you can edit the fields of the excursion. Then press "Save" to save your changes.

Rubric:
A. This app has been created in Gitlab through pipeline with commits for B1-5. Submission Includes git repo url, picture of repo branch history, storyboard, signed apk, screenshots of signed apk creation, and this read me file.
B1. This app uses a Room Framework to add, delete, edit vacations consistently and accurately including validations.
B2. The add vacation feature allows users to add details of title, hotel/accommodation, start, and end date for each vacation
B3. The app allows users to enter to see a detailed view of the vacation, edit the vacation, date validations, allows users to trigger an alert based on start and end date, allows users to share selected vacations, and allows users to add/delete/edit excursions.
B4. Excursions are unique to each vacation and includes title and date.
C. Has all required GUI elements: A home screen, list of vacations on the home screen, list of excursions associated to vacations under each vacation, a detailed vacation and excursion view.
D. Storyboard will be included in submission.
E. Screenshots of signed APK will be included in submission
F. This readme file in the project folder along with a word doc version will be included in submission.

## Android Version
Minimum: Android 7
Targeted: Android 15

## Git Repo
https://gitlab.com/wgu-gitlab-environment/student-repos/zfeng21/d308-mobile-application-development-android