package com.example.ziapp.UI;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.ziapp.R;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import database.AppDatabase;
import database.ExcursionAdapter;
import database.entities.Excursion;
import database.entities.Vacation;
import notification.NotificationHelper;

import java.util.stream.Collectors;

public class EditVacationActivity extends AppCompatActivity {

    private TextView selectModeTitle;
    private EditText titleEdit, accommodationEdit, startDateEdit, endDateEdit;
    private SwitchCompat alertSwitch;
    private boolean alertEnabled = false;
    private Button saveButton, addExcursionButton, exitSelectModeButton, removeExcursionButton;
    private AppDatabase db;
    private Vacation vacation;
    private LinearLayout vacationDetailsSection, excursionSection;
    private RecyclerView excursionRecyclerView;
    private ExcursionAdapter excursionAdapter;
    private int vacationId;
    private Executor executor;
    private List<Excursion> selectedExcursions = new ArrayList<>();
    private ActivityResultLauncher<Intent> addExcursionLauncher, editExcursionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_vacation);

        addExcursionLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        loadExcursionsForVacation(vacationId);
                        excursionAdapter.notifyDataSetChanged();
                    }
                });



        selectModeTitle = findViewById(R.id.selectModeTitle); //Select Mode Indicator
        selectModeTitle.setVisibility(View.GONE);

        exitSelectModeButton = findViewById(R.id.exitSelectModeButton); //Exit Select Mode Button
        exitSelectModeButton.setVisibility(View.GONE);
        exitSelectModeButton.setOnClickListener(v -> exitSelectMode());

        removeExcursionButton = findViewById(R.id.removeExcursionButton); //Delete Excursion Button
        removeExcursionButton.setVisibility(View.GONE);
        removeExcursionButton.setOnClickListener(v -> confirmExcursionDeletion());

        addExcursionButton = findViewById(R.id.addExcursionButton); //Add Excursion Button
        addExcursionButton.setOnClickListener(this::addExcursion);

        saveButton = findViewById(R.id.saveButton); //Save Vacation Button
        saveButton.setOnClickListener(v -> updateVacation());

        executor = Executors.newSingleThreadExecutor();

        vacationDetailsSection = findViewById(R.id.vacationDetailsSection); //Vacation Details Tab
        titleEdit = findViewById(R.id.edittitletextv);
        accommodationEdit = findViewById(R.id.editaccommodationtextv);
        startDateEdit = findViewById(R.id.editstartdatetextv);
        endDateEdit = findViewById(R.id.editenddatetextv);
        alertSwitch = findViewById(R.id.mainAlertSwitch);

        alertSwitch.setChecked(alertEnabled); //Vacation Alert Switch
        alertSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> alertEnabled = isChecked);

        excursionSection = findViewById(R.id.excursionsSection); //Excursion Tab
        excursionRecyclerView = findViewById(R.id.excursionsRecyclerView);
        excursionRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        excursionRecyclerView.setAdapter(excursionAdapter);


        db = AppDatabase.getInstance(this);
        if (db == null) {
            Toast.makeText(this, "Database initialization failed", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        vacationId = getIntent().getIntExtra("VACATION_ID", -1);
        if (vacationId == -1) {
            Toast.makeText(this, "Error loading vacation", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadVacationDetails(vacationId);
    }

    private void loadVacationDetails(int vacationId) {
        new Thread(() -> {
            vacation = db.vacationDao().getVacationById(vacationId);
            runOnUiThread(() -> {
                if (vacation != null) {
                    titleEdit.setText(vacation.getTitle());
                    accommodationEdit.setText(vacation.getAccommodation());
                    startDateEdit.setText(vacation.getStartDate());
                    endDateEdit.setText(vacation.getEndDate());
                    alertSwitch.setChecked(vacation.isAlert());
                    alertEnabled = vacation.isAlert();

                    loadExcursions();
                } else {
                    Toast.makeText(this, "Vacation not found", Toast.LENGTH_SHORT).show();
                    finish();
                }
            });
        }).start();
    }

    private void loadExcursions() {
        new Thread(() -> {
            List<Excursion> excursionList = db.excursionDao().getExcursionsByVacationId(vacationId);
            runOnUiThread(() -> {
                excursionAdapter = new ExcursionAdapter(this, excursionList, addExcursionLauncher, db, vacation);
                excursionRecyclerView.setAdapter(excursionAdapter);
                excursionAdapter.notifyDataSetChanged();
            });
        }).start();
    }

    private void confirmExcursionDeletion() {
        List<Excursion> selectedExcursions = excursionAdapter.getSelectedExcursions();

        if (selectedExcursions.isEmpty()) {
            Toast.makeText(this, "No excursions selected", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Confirm Deletion")
                .setMessage("Are you sure you want to delete selected excursions?")
                .setPositiveButton("Yes", (dialog, which) -> deleteExcursions(selectedExcursions))
                .setNegativeButton("No", null)
                .show();
    }

    private void deleteExcursions(List<Excursion> excursions) {
        new Thread(() -> {
            for (Excursion excursion : excursions) {
                db.excursionDao().deleteE(excursion);
            }
            runOnUiThread(() -> {
                loadExcursions();
                excursionAdapter.resetSelectMode();
                Toast.makeText(this, "Excursions deleted successfully", Toast.LENGTH_SHORT).show();
            });
        }).start();
    }

    private void addExcursion(View view) {
        Intent intent = new Intent(EditVacationActivity.this, AddExcursion.class);
        intent.putExtra("vacationId", vacationId);
        addExcursionLauncher.launch(intent);
    }


    private void loadExcursionsForVacation(int vacationId) {
        executor.execute(() -> {
            List<Excursion> excursions = db.excursionDao().getExcursionsByVacationId(vacationId);
            runOnUiThread(() -> updateExcursionsList(excursions));
        });
    }


    public void toggleVacationDetails(View view) {
        if (vacationDetailsSection.getVisibility() == View.VISIBLE) {
            vacationDetailsSection.setVisibility(View.GONE);
        } else {
            vacationDetailsSection.setVisibility(View.VISIBLE);
        }
    }

    public void toggleExcursions(View view) {
        if (excursionSection.getVisibility() == View.VISIBLE) {
            excursionSection.setVisibility(View.GONE);
        } else {
            excursionSection.setVisibility(View.VISIBLE);
        }
    }

    private void updateVacation() {
        String newTitle = titleEdit.getText().toString().trim();
        String newAccommodation = accommodationEdit.getText().toString().trim();
        String newStartDate = startDateEdit.getText().toString().trim();
        String newEndDate = endDateEdit.getText().toString().trim();

        vacation.setTitle(newTitle);
        vacation.setAccommodation(newAccommodation);
        vacation.setStartDate(newStartDate);
        vacation.setEndDate(newEndDate);
        vacation.setAlert(alertEnabled);

        if (newTitle.isEmpty() || newAccommodation.isEmpty() || newStartDate.isEmpty() || newEndDate.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return;
        }
        if (isValidDate(newStartDate) || isValidDate(newEndDate)) {
            Toast.makeText(this, "Invalid date format. Please use MM-DD-YYYY", Toast.LENGTH_SHORT).show();
            return;
        }

        if (isStartDateAfterEndDate(newStartDate, newEndDate)) {
            Toast.makeText(this, "Start date cannot be after end date", Toast.LENGTH_SHORT).show();
            return;
        }

        Context context = this;

        new Thread(() -> {
            db.vacationDao().updatev(vacation);
            runOnUiThread(() -> {
                Toast.makeText(this, "Vacation updated!", Toast.LENGTH_SHORT).show();

                if (vacation.isAlert()) {
                    NotificationHelper.scheduleVacationNotifications(context, vacation);
                }

                setResult(RESULT_OK);
                finish();
            });
        }).start();
    }
    private boolean isValidDate(String date) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy", Locale.US);
            dateFormat.setLenient(false);
            dateFormat.parse(date);
            return false;
        } catch (ParseException e) {
            return true;
        }
    }
    private boolean isStartDateAfterEndDate(String startDate, String endDate) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy", Locale.US);
            Date start = dateFormat.parse(startDate);
            Date end = dateFormat.parse(endDate);
            return start != null && end != null && start.after(end);
        } catch (ParseException e) {
            return false;
        }
    }

    public void updateExcursionsList(List<Excursion> excursions) {
        if (excursionAdapter != null) {
            excursionAdapter.updateData(excursions);
        } else {
            excursionAdapter = new ExcursionAdapter(this, excursions, addExcursionLauncher, db, vacation);
            excursionRecyclerView.setAdapter(excursionAdapter);
        }
    }

    public void refreshExcursions() {
        new Thread(() -> {
            List<Excursion> updatedExcursions = db.excursionDao().getExcursionsByVacationId(vacation.getId());

            runOnUiThread(() -> {
                updateExcursionsList(updatedExcursions);
            });
        }).start();
    }

    public void enterSelectMode() {
        selectModeTitle.setVisibility(View.VISIBLE);
        exitSelectModeButton.setVisibility(View.VISIBLE);
        removeExcursionButton.setVisibility(View.VISIBLE);

        saveButton.setVisibility(View.GONE);
        addExcursionButton.setVisibility(View.GONE);
    }

    public void exitSelectMode() {
        selectModeTitle.setVisibility(View.GONE);
        exitSelectModeButton.setVisibility(View.GONE);
        removeExcursionButton.setVisibility(View.GONE);

        saveButton.setVisibility(View.VISIBLE);
        addExcursionButton.setVisibility(View.VISIBLE);

        if (excursionAdapter != null && excursionAdapter.isSelectMode()) {
            excursionAdapter.resetSelectMode();
        }
    }


}

