package com.example.ziapp.UI;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import com.example.ziapp.R;

import database.AppDatabase;
import database.entities.Vacation;
import notification.NotificationHelper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;


public class AddVacation extends AppCompatActivity {

    private EditText titletextv, accommodationtextv, startdatetextv, enddatetextv;
    private Button submitbutton;
    private AppDatabase db;
    private SwitchCompat mainAlertSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addvacation);

        titletextv = findViewById(R.id.edittitletextv);
        accommodationtextv = findViewById(R.id.editaccommodationtextv);
        startdatetextv = findViewById(R.id.editstartdatetextv);
        enddatetextv = findViewById(R.id.editenddatetextv);
        mainAlertSwitch = findViewById(R.id.mainAlertSwitch);

        mainAlertSwitch.setChecked(false);

        db = AppDatabase.getInstance(this);

        submitbutton = findViewById(R.id.saveButton);
        submitbutton.setOnClickListener(v -> saveVacation());

    }
    private void saveVacation() {
        String title = titletextv.getText().toString().trim();
        String accommodation = accommodationtextv.getText().toString().trim();
        String startDate = startdatetextv.getText().toString().trim();
        String endDate = enddatetextv.getText().toString().trim();

        if (TextUtils.isEmpty(title) || TextUtils.isEmpty(accommodation) ||
                TextUtils.isEmpty(startDate) || TextUtils.isEmpty(endDate)) {
            Toast.makeText(this, "All fields must be filled", Toast.LENGTH_SHORT).show();
            return;
        }

        if (isValidDate(startDate) || isValidDate(endDate)) {
            Toast.makeText(this, "Dates must be in MM-DD-YYYY format", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!isStartDateBeforeEndDate(startDate, endDate)) {
            Toast.makeText(this, "Start date must be before end date", Toast.LENGTH_SHORT).show();
            return;
        }

        Vacation vacation = new Vacation(title, accommodation, startDate, endDate);
        vacation.setAlert(mainAlertSwitch.isChecked());
        Context context = this;

        new Thread(() -> {
            db.vacationDao().insertv(vacation);
            runOnUiThread(() -> {
                Toast.makeText(this, "Vacation Added", Toast.LENGTH_SHORT).show();

                if (vacation.isAlert()) {
                    NotificationHelper.scheduleVacationNotifications(context, vacation);
                }

                Intent resultIntent = new Intent();
                setResult(RESULT_OK, resultIntent);
                finish();
            });
        }).start();
    }
    private boolean isValidDate(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.US);
        sdf.setLenient(false);
        try {
            sdf.parse(date);
            return false;
        } catch (ParseException e) {
            return true;
        }
    }

    private boolean isStartDateBeforeEndDate(String start, String end) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.US);
        try {
            return !sdf.parse(start).after(sdf.parse(end));
        } catch (ParseException e) {
            return false;
        }
    }
}