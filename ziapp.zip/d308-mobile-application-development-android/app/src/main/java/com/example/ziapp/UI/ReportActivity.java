package com.example.ziapp.UI;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ziapp.R;

import java.util.List;

import database.AppDatabase;
import database.ReportAdapter;
import database.entities.Vacation;

public class ReportActivity extends AppCompatActivity {

    private RecyclerView reportRecyclerView;
    private Button returnMainButton;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        returnMainButton = findViewById(R.id.returnMainButton);
        returnMainButton.setOnClickListener(v -> {
            Intent intent = new Intent(ReportActivity.this, MainActivity.class);
            startActivity(intent);
        });

        reportRecyclerView = findViewById(R.id.reportRecyclerView);
        reportRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        db = AppDatabase.getInstance(this);

        loadReport();
    }

    private void loadReport() {
        new Thread(() -> {
            List<Vacation> vacationList = db.vacationDao().getAllVacations();
            String timestamp = new java.text.SimpleDateFormat("MM-dd-yyyy HH:mm", java.util.Locale.US).format(new java.util.Date());

            runOnUiThread(() -> {
                TextView reportTime = findViewById(R.id.reportTime);
                reportTime.setText("Report generated: " + timestamp);
                reportRecyclerView.setAdapter(new ReportAdapter(vacationList, db));
            });
        }).start();
    }
}
