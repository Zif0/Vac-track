package com.example.ziapp.UI;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ziapp.R;
import java.util.ArrayList;
import java.util.List;


import database.AppDatabase;
import database.VacationAdapter;
import database.entities.Vacation;


public class MainActivity extends AppCompatActivity {

    private List<Vacation> filteredVacationList, vacationList;
    private RecyclerView recyclerView;
    private VacationAdapter adapter;
    private AppDatabase db;
    private TextView selectStatus;
    private Button exitButton, Add, Remove, infoButton, Share, reportButton;
    private EditText searchVacation;
    ActivityResultLauncher<Intent> vacationLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        vacationLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        loadVacations();
                    }
                }
        );

        searchVacation = findViewById(R.id.searchVacation); //Search Vacations
        searchVacation.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterVacations(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });

        selectStatus = findViewById(R.id.selectStatus); //Select Mode Message
        selectStatus.setVisibility(View.GONE);

        reportButton = findViewById(R.id.reportButton);
        reportButton.setVisibility(View.GONE);
        reportButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ReportActivity.class);
            startActivity(intent);
        });

        exitButton = findViewById(R.id.exitButton); //Exit Select Mode Button
        exitButton.setVisibility(View.GONE);
        exitButton.setOnClickListener(v -> exitSelectMode());

        Add = findViewById(R.id.AddButton); //Button to Add Vacations
        Add.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddVacation.class);
            vacationLauncher.launch(intent);
        });

        Remove = findViewById(R.id.RemoveButton); //Button to Remove Vacations
        Remove.setVisibility(View.GONE);
        Remove.setOnClickListener(v -> confirmDeletion());

        Share = findViewById(R.id.shareButton); //Button to Share Vacations
        Share.setVisibility(View.GONE);
        Share.setOnClickListener(v -> {
            if (adapter != null) {
                shareSelectedVacations(adapter.getSelectedVacations());
            } else {
                Toast.makeText(this, "Error: No vacations loaded", Toast.LENGTH_SHORT).show();
            }
        });

        infoButton = findViewById(R.id.infoButton);
        infoButton.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("How to Manage Vacations")
                    .setMessage("• Tap the 'Add Vacation' button to add a new vacation.\n" +
                            "• Tap a vacation to edit details or add excursions.\n" +
                            "• Long press a vacation to enter select mode.\n" +
                            "• While in select mode, tap vacations then tap 'Remove Vacation' to delete selected vacations.\n" +
                            "• You can generate a report of all your vacation and excursion activity with 'Generate Report'.\n" +
                            "• You can exit select mode with the 'Exit Select Mode' button.")
                    .setPositiveButton("OK", null)
                    .show();
                });

        recyclerView = findViewById(R.id.vacationlist); //Vacations List
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        db = AppDatabase.getInstance(this);
        loadVacations();
    }
    private void loadVacations() {
        new Thread(() -> {
            vacationList = db.vacationDao().getAllVacations();
            filteredVacationList = new ArrayList<>(vacationList);
            runOnUiThread(() -> {
                adapter = new VacationAdapter(this, vacationList, filteredVacationList, vacationLauncher);
                recyclerView.setAdapter(adapter);
            });
        }).start();
    }
    private void confirmDeletion() {
        if (adapter == null) {
            Toast.makeText(this, "Error: No vacations loaded", Toast.LENGTH_SHORT).show();
            return;
        }

        List<Vacation> selectedVacations = adapter.getSelectedVacations();
        if (selectedVacations.isEmpty()) {
            Toast.makeText(this, "No vacations selected", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Confirm Deletion")
                .setMessage("Are you sure you want to delete selected vacations?")
                .setPositiveButton("Yes", (dialog, which) -> deleteVacations(selectedVacations))
                .setNegativeButton("No", null)
                .show();
    }

    private void deleteVacations(List<Vacation> vacations) {
        new Thread(() -> {
            final boolean[] allDeleted = {true};
            for (Vacation vacation : vacations) {
                if (!db.excursionDao().getExcursionsByVacationId(vacation.getId()).isEmpty()) {
                    allDeleted[0] = false;
                    runOnUiThread(() -> Toast.makeText(this, "Cannot delete vacation with excursions", Toast.LENGTH_SHORT).show());
                } else {
                    db.vacationDao().deletev(vacation);
                }
            }
            runOnUiThread(() -> {
                loadVacations();
                adapter.resetSelectMode();
                if (allDeleted[0]) {
                    Toast.makeText(this, "Vacations deleted successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Some vacations could not be deleted", Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }
    private void shareSelectedVacations(List<Vacation> vacations) {
        if (vacations.isEmpty()) {
            Toast.makeText(this, "No vacations selected to share.", Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuilder shareContent = new StringBuilder();
        for (Vacation vacation : vacations) {
            shareContent.append("Title: ").append(vacation.getTitle()).append("\n")
                    .append("Accommodation: ").append(vacation.getAccommodation()).append("\n")
                    .append("Start Date: ").append(vacation.getStartDate()).append("\n")
                    .append("End Date: ").append(vacation.getEndDate()).append("\n\n");
        }

        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareContent.toString());

        startActivity(Intent.createChooser(shareIntent, "Share Vacation Details"));
    }

    public void enterSelectMode() {
        selectStatus.setVisibility(View.VISIBLE);
        exitButton.setVisibility(View.VISIBLE);
        Share.setVisibility(View.VISIBLE);
        Remove.setVisibility(View.VISIBLE);
        reportButton.setVisibility(View.VISIBLE);

        infoButton.setVisibility(View.GONE);
        Add.setVisibility(View.GONE);
    }
    public void exitSelectMode() {
        selectStatus.setVisibility(View.GONE);
        exitButton.setVisibility(View.GONE);
        Share.setVisibility(View.GONE);
        Remove.setVisibility(View.GONE);
        reportButton.setVisibility(View.GONE);

        infoButton.setVisibility(View.VISIBLE);
        Add.setVisibility(View.VISIBLE);

        if (adapter != null && adapter.isSelectMode()) {
            adapter.resetSelectMode();
        }
    }

    private void filterVacations(String query) {
        if (filteredVacationList == null || vacationList == null) {
            return;
        }
        filteredVacationList.clear();
        if (query.isEmpty()) {
            filteredVacationList.addAll(vacationList);
        } else {
            String lowerCaseQuery = query.toLowerCase();
            for (Vacation vacation : vacationList) {
                if (vacation.getTitle().toLowerCase().contains(lowerCaseQuery)) {
                    filteredVacationList.add(vacation);
                }
            }
        }
        adapter.notifyDataSetChanged();
    }

}