package com.example.ziapp.UI;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import com.example.ziapp.R;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import database.AppDatabase;
import database.entities.Excursion;

public class EditExcursionActivity extends AppCompatActivity {

    private TextView editExcursionTitle, editExcursionDate;
    private EditText editExcursionTitleText, editExcursionDateText;
    private SwitchCompat editExcursionAlertSwitch;
    private Button editSaveButton;
    private AppDatabase db;
    private Excursion excursion;
    private String vacationStartDate, vacationEndDate;
    private int vacationId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_excursion);

        db = AppDatabase.getInstance(this);

        editExcursionTitleText = findViewById(R.id.editExcursionTitleText);
        editExcursionTitle = findViewById(R.id.editExcursionTitle);

        editExcursionDateText = findViewById(R.id.editExcursionDateText);
        editExcursionDate = findViewById(R.id.editExcursionDate);

        editExcursionAlertSwitch = findViewById(R.id.editExcursionAlertSwitch);
        editSaveButton = findViewById(R.id.editSaveButton);


        Intent intent = getIntent();
        if (intent.hasExtra("excursionId") && intent.hasExtra("vacationStartDate") && intent.hasExtra("vacationEndDate") && intent.hasExtra("vacationId")) {
            int excursionId = intent.getIntExtra("excursionId", -1);
            vacationStartDate = intent.getStringExtra("vacationStartDate");
            vacationEndDate = intent.getStringExtra("vacationEndDate");
            vacationId = intent.getIntExtra("vacationId", -1);

            if (excursionId != -1) {
                new Thread(() -> {
                    excursion = db.excursionDao().getExcursionById(excursionId);
                    runOnUiThread(() -> {
                        if (excursion != null) {
                            editExcursionTitleText.setText(excursion.getTitle());
                            editExcursionDateText.setText(excursion.getDate());
                            editExcursionAlertSwitch.setChecked(excursion.isAlert());
                        }
                    });
                }).start();
            }
        }


        editSaveButton.setOnClickListener(v -> {
            String newTitle = editExcursionTitleText.getText().toString().trim();
            String newDate = editExcursionDateText.getText().toString().trim();
            boolean alertEnabled = editExcursionAlertSwitch.isChecked();


            if (newTitle.isEmpty() || newDate.isEmpty()) {
                Toast.makeText(this, "All fields must be filled out.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (isValidDateFormat(newDate)) {
                Toast.makeText(this, "Invalid date format. Use MM-DD-YYYY.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!isDateWithinVacation(newDate, vacationStartDate, vacationEndDate)) {
                Toast.makeText(this, "Excursion date must be within vacation period.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (excursion != null) {
                excursion.setTitle(newTitle);
                excursion.setDate(newDate);
                excursion.setAlert(alertEnabled);

                new Thread(() -> {
                    db.excursionDao().updateE(excursion);
                    runOnUiThread(() -> {
                        Toast.makeText(this, "Excursion updated", Toast.LENGTH_SHORT).show();
                        setResult(RESULT_OK);
                        finish();
                    });
                }).start();
            }
        });
    }

    private boolean isValidDateFormat(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.US);
        sdf.setLenient(false);
        try {
            sdf.parse(date);
            return false;
        } catch (ParseException e) {
            return true;
        }
    }

    private boolean isDateWithinVacation(String date, String startDate, String endDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.US);
        sdf.setLenient(false);
        try {
            Date enteredDate = sdf.parse(date);
            Date vacationStart = sdf.parse(startDate);
            Date vacationEnd = sdf.parse(endDate);
            return !enteredDate.before(vacationStart) && !enteredDate.after(vacationEnd);
        } catch (ParseException e) {
            return false;
        }
    }

}

