package com.example.ziapp.UI;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import com.example.ziapp.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import database.AppDatabase;
import database.entities.Excursion;
import notification.NotificationHelper;

public class AddExcursion extends AppCompatActivity {

    private EditText excursionTitleEdit, excursionDateEdit;
    private SwitchCompat excursionAlertSwitch;
    private Button excursionSubmitButton;
    private int vacationId;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_excursion);

        vacationId = getIntent().getIntExtra("vacationId", -1);

        excursionTitleEdit = findViewById(R.id.excursionTitleEdit);
        excursionDateEdit = findViewById(R.id.excursionDateEdit);
        excursionAlertSwitch = findViewById(R.id.excursionAlertSwitch);
        excursionSubmitButton = findViewById(R.id.excursionSubmitButton);


        db = AppDatabase.getInstance(this);


        excursionSubmitButton.setOnClickListener(v -> saveExcursion());
    }
    private void saveExcursion() {
        String title = excursionTitleEdit.getText().toString().trim();
        String date = excursionDateEdit.getText().toString().trim();

        if (TextUtils.isEmpty(title) || TextUtils.isEmpty(date)) {
            Toast.makeText(this, "All fields must be filled", Toast.LENGTH_SHORT).show();
            return;
        }

        if (isValidDateFormat(date)) {
            Toast.makeText(this, "Date must be in MM-DD-YYYY format", Toast.LENGTH_SHORT).show();
            return;
        }

        new Thread(() -> {
            database.entities.Vacation vacation = db.vacationDao().getVacationById(vacationId);
            if (vacation == null) {
                runOnUiThread(() -> Toast.makeText(this, "Vacation not found!", Toast.LENGTH_SHORT).show());
                return;
            }

            String vacationStartDate = vacation.getStartDate();
            String vacationEndDate = vacation.getEndDate();

            if (!isDateWithinVacation(date, vacationStartDate, vacationEndDate)) {
                runOnUiThread(() -> Toast.makeText(this, "Excursion date must be within vacation dates!", Toast.LENGTH_SHORT).show());
                return;
            }

            boolean isAlertEnabled = excursionAlertSwitch.isChecked();
            Excursion excursion = new Excursion(title, date, vacationId, isAlertEnabled);

            db.excursionDao().insertE(excursion);

            List<Excursion> excursions = db.excursionDao().getExcursionsByVacationId(vacationId);

            Context context = this;

            runOnUiThread(() -> {
                if (excursions != null && !excursions.isEmpty()) {
                    Toast.makeText(this, "Excursion Added Successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Excursion Insert Failed", Toast.LENGTH_SHORT).show();
                }

                if (excursion.isAlert()) {
                    NotificationHelper.scheduleExcursionNotification(context, excursion);
                }
                Intent resultIntent = new Intent();
                setResult(RESULT_OK, resultIntent);
                finish();
            });
        }).start();
    }

    private boolean isValidDateFormat(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.US);
        sdf.setLenient(false);
        try {
            sdf.parse(date);
            return false;
        } catch (ParseException e) {
            return true;
        }
    }

    private boolean isDateWithinVacation(String date, String startDate, String endDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.US);
        sdf.setLenient(false);

        try {
            Date enteredDate = sdf.parse(date);
            Date vacationStart = sdf.parse(startDate);
            Date vacationEnd = sdf.parse(endDate);

            return !enteredDate.before(vacationStart) && !enteredDate.after(vacationEnd);

        } catch (ParseException e) {
            return false;
        }
    }
}
