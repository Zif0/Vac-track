package com.example.ziapp.UI;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.ziapp.R;

public class LoginActivity extends AppCompatActivity {

    private TextView usernameTitle, passwordTitle;
    private EditText usernameText, passwordText;
    private Button loginButton, loginInformation;

    private static final String PREFS_NAME = "LoginPrefs";
    private static final String USERNAME_KEY = "username";
    private static final String PASSWORD_KEY = "password";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameTitle = findViewById(R.id.usernameTitle);
        passwordTitle = findViewById(R.id.passwordTitle);
        usernameText = findViewById(R.id.usernameText);
        passwordText = findViewById(R.id.passwordText);
        loginButton = findViewById(R.id.loginButton);
        loginInformation = findViewById(R.id.loginInformation);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        loginButton.setOnClickListener(v -> {
            String username = usernameText.getText().toString();
            String password = passwordText.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both fields", Toast.LENGTH_SHORT).show();
                return;
            }

            String savedUsername = prefs.getString(USERNAME_KEY, null);
            String savedPassword = prefs.getString(PASSWORD_KEY, null);

            if (savedUsername == null && savedPassword == null) {
                prefs.edit()
                        .putString(USERNAME_KEY, username)
                        .putString(PASSWORD_KEY, password)
                        .apply();
                Toast.makeText(this, "Account created and logged in", Toast.LENGTH_SHORT).show();
                openMain();
            } else if (username.equals(savedUsername) && password.equals(savedPassword)) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                openMain();
            } else {
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });

        loginInformation.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Login Info")
                    .setMessage("• On your first login, an account will be created with the username and password you enter.\n" +
                            "• This app stores your credentials locally.\n" +
                            "• On future launches, use the same credentials to log in.")
                    .setPositiveButton("OK", null)
                    .show();
        });
    }

    private void openMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
