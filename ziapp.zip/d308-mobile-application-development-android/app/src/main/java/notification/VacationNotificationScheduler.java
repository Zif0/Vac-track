package notification;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import database.entities.Vacation;

public class VacationNotificationScheduler {

    public static void scheduleVacationAlerts(Context context, Vacation vacation) {
        if (!vacation.isAlert()) return;

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.US);

        try {
            Date startDate = sdf.parse(vacation.getStartDate());
            Date endDate = sdf.parse(vacation.getEndDate());


            if (startDate != null) {
                scheduleAlarm(context, alarmManager, vacation.getId(), startDate, NotificationHelper.NOTIFICATION_ID_START);
            }


            if (endDate != null) {
                scheduleAlarm(context, alarmManager, vacation.getId(), endDate, NotificationHelper.NOTIFICATION_ID_END);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private static void scheduleAlarm(Context context, AlarmManager alarmManager,
                                      int vacationId, Date date, int notificationId) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);


        Intent intent = new Intent(context, NotificationReceiver.class);
        intent.putExtra("notification_id", notificationId);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                vacationId + notificationId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                calendar.getTimeInMillis(),
                pendingIntent
        );
    }
}
