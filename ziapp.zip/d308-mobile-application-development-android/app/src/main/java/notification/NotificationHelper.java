package notification;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.example.ziapp.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import database.entities.Excursion;
import database.entities.Vacation;

public class NotificationHelper {
    public static final int NOTIFICATION_ID_START = 1;
    public static final int NOTIFICATION_ID_END = 2;
    public static final int NOTIFICATION_ID_EXCURSION = 3;


    private Context context;

    public NotificationHelper(Context context) {

        this.context = context;
    }

    public void scheduleVacationStartNotification(long startTimeMillis) {
        if (startTimeMillis <= System.currentTimeMillis()) return;

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, NotificationReceiver.class);
        intent.putExtra("notification_id", NOTIFICATION_ID_START);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, NOTIFICATION_ID_START, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        alarmManager.setExact(AlarmManager.RTC_WAKEUP, startTimeMillis, pendingIntent);
    }

    public void scheduleVacationEndNotification(long endTimeMillis) {
        if (endTimeMillis <= System.currentTimeMillis()) return;

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, NotificationReceiver.class);
        intent.putExtra("notification_id", NOTIFICATION_ID_END);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, NOTIFICATION_ID_END, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        alarmManager.setExact(AlarmManager.RTC_WAKEUP, endTimeMillis, pendingIntent);
    }

    public static void scheduleVacationNotifications(Context context,Vacation vacation) {
        NotificationHelper notificationHelper = new NotificationHelper(context);

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.US);

            Date startDate = sdf.parse(vacation.getStartDate());
            Date endDate = sdf.parse(vacation.getEndDate());

            if (startDate != null) {
                notificationHelper.scheduleVacationStartNotification(startDate.getTime());
            }

            if (endDate != null) {
                notificationHelper.scheduleVacationEndNotification(endDate.getTime());
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public void scheduleExcursionDateNotification(long excursionTimeMillis) {
        if (excursionTimeMillis <= System.currentTimeMillis()) return;

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, NotificationReceiver.class);
        intent.putExtra("notification_id", NOTIFICATION_ID_EXCURSION);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, NOTIFICATION_ID_EXCURSION, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        alarmManager.setExact(AlarmManager.RTC_WAKEUP, excursionTimeMillis, pendingIntent);
    }

    public static void scheduleExcursionNotification(Context context, Excursion excursion) {
        NotificationHelper notificationHelper = new NotificationHelper(context);

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.US);

            Date date = sdf.parse(excursion.getDate());

            if (date != null) {
                notificationHelper.scheduleExcursionDateNotification(date.getTime());
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }


    public void sendNotification(String title, String message, int notificationId) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
                return;
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Vacation Notifications";
            String description = "Notifications for vacation start and end.";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("vacation_channel", name, importance);
            channel.setDescription(description);
            notificationManager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context, "vacation_channel")
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        notificationManager.notify(notificationId, notificationBuilder.build());
    }
}