package notification;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class NotificationReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        int notificationId = intent.getIntExtra("notification_id", 0);
        NotificationHelper notificationHelper = new NotificationHelper(context);

        switch (notificationId) {
            case NotificationHelper.NOTIFICATION_ID_START:
                notificationHelper.sendNotification("Vacation Started!", "Your vacation has begun.", notificationId);
                break;
            case NotificationHelper.NOTIFICATION_ID_END:
                notificationHelper.sendNotification("Vacation Ended", "Your vacation has ended.", notificationId);
                break;
            case NotificationHelper.NOTIFICATION_ID_EXCURSION:
                String title = intent.getStringExtra("excursion_title");
                notificationHelper.sendNotification("Excursion Today", title, notificationId);
                break;
        }
    }
}