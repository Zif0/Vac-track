package database;

import android.content.Intent;
import android.graphics.Color;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ziapp.R;
import com.example.ziapp.UI.EditExcursionActivity;
import com.example.ziapp.UI.EditVacationActivity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import android.os.Handler;

import database.entities.Excursion;
import database.entities.Vacation;

public class ExcursionAdapter extends RecyclerView.Adapter<ExcursionAdapter.ExcursionViewHolder> {
    private List<Excursion> excursionList;
    private Set<Integer> selectedExcursions = new HashSet<>();
    private boolean selectMode = false;
    private EditVacationActivity editVacationActivity;
    private ActivityResultLauncher<Intent> excursionLauncher;
    private AppDatabase db;
    private Vacation vacation;

    public ExcursionAdapter(EditVacationActivity editVacationActivity, List<Excursion> excursionList, ActivityResultLauncher<Intent> excursionLauncher, AppDatabase db, Vacation vacation) {
        this.excursionList = excursionList;
        this.editVacationActivity = editVacationActivity;
        this.excursionLauncher = excursionLauncher;
        this.db = db;
        this.vacation = vacation;
    }

    @NonNull
    @Override
    public ExcursionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_excursion, parent, false);
        return new ExcursionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ExcursionViewHolder holder, int position) {
        Excursion excursion = excursionList.get(position);

        holder.title.setText(excursion.getTitle());
        holder.date.setText(excursion.getDate());

        holder.itemView.setBackgroundColor(selectedExcursions.contains(position) ? Color.LTGRAY : Color.WHITE);

        holder.itemView.setOnLongClickListener(v -> {
            if (!selectMode) {
                selectMode = true;
                selectedExcursions.clear();
                notifySelectMode();
                notifyDataSetChanged();
            }
            return true;
        });

        holder.itemView.setOnClickListener(v -> {
            if (selectMode) {
                toggleSelection(position);
            } else {
                Intent intent = new Intent(v.getContext(), EditExcursionActivity.class);
                intent.putExtra("excursionId", excursion.getId());
                intent.putExtra("vacationId", vacation.getId());
                intent.putExtra("vacationStartDate", vacation.getStartDate());
                intent.putExtra("vacationEndDate", vacation.getEndDate());
                excursionLauncher.launch(intent);
            }
        });
    }

    private void toggleSelection(int position) {
        if (selectedExcursions.contains(position)) {
            selectedExcursions.remove(position);
        } else {
            selectedExcursions.add(position);
        }
        notifyDataSetChanged();
        if (selectedExcursions.isEmpty()) {
            notifySelectMode();
        }
    }

    private void notifySelectMode() {
        if (editVacationActivity != null) {
            editVacationActivity.enterSelectMode();
        }
    }

    public boolean isSelectMode() {
        return selectMode;
    }

    public void resetSelectMode() {
        selectMode = false;
        selectedExcursions.clear();
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return excursionList.size();
    }

    public static class ExcursionViewHolder extends RecyclerView.ViewHolder {
        TextView title, date;

        public ExcursionViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.excursionTitle);
            date = itemView.findViewById(R.id.excursionDate);
        }
    }

    public List<Excursion> getSelectedExcursions() {
        List<Excursion> selectedExcursionsList = new ArrayList<>();
        for (int position : selectedExcursions) {
            if (position >= 0 && position < excursionList.size()) {
                selectedExcursionsList.add(excursionList.get(position));
            }
        }
        return selectedExcursionsList;
    }

    public void updateData(List<Excursion> newExcursionList) {
        excursionList.clear();
        excursionList.addAll(newExcursionList);
        notifyDataSetChanged();
    }


}