package database.entities;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "excursions", foreignKeys = @ForeignKey(entity = Vacation.class,
        parentColumns = "id",
        childColumns = "vacationId",
        onDelete = ForeignKey.CASCADE),
        indices = {@Index("vacationId")})
public class Excursion {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String title;
    private String date;
    private int vacationId;
    private boolean alert;
    private boolean selected = false;

    public Excursion(String title, String date, int vacationId, boolean alert) {
        this.title = title;
        this.date = date;
        this.vacationId = vacationId;
        this.alert = alert;
    }


    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getDate() { return date; }
    public int getVacationId() { return vacationId; }
    public boolean isAlert() { return alert; }


    public void setId(int id) { this.id = id; }
    public void setTitle(String title) { this.title = title; }
    public void setDate(String date) { this.date = date; }
    public boolean isSelected() {
        return selected;
    }

    public void setVacationId(int vacationId) { this.vacationId = vacationId; }
    public void setAlert(boolean alert) { this.alert = alert; }
    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}
