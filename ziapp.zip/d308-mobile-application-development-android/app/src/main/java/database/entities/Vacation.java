package database.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "vacations")
public class Vacation {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String title;
    public String accommodation;
    public String startdate;
    public String enddate;
    private boolean isSelected = false;
    private boolean alert;

    public Vacation(String title, String accommodation, String startdate, String enddate) {
        this.title = title;
        this.accommodation = accommodation;
        this.startdate = startdate;
        this.enddate = enddate;
        this.alert = false;
    }

    public int getId() {
        return id;
    }
    public String getTitle() {
        return title;
    }

    public String getAccommodation() {
        return accommodation;
    }

    public String getStartDate() {
        return startdate;
    }

    public String getEndDate() {
        return enddate;
    }
    public boolean isAlert() {
        return alert;
    }


    public void setId(int id) {
        this.id = id;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public void setAccommodation(String accommodation) {
        this.accommodation = accommodation;
    }
    public void setStartDate(String startdate) {
        this.startdate = startdate;
    }
    public void setEndDate(String enddate) {
        this.enddate = enddate;
    }
    public boolean isSelected(){
        return isSelected;
    }
    public void setSelected(boolean selected) {
        isSelected = selected;
    }
    public void setAlert(boolean alert) {
        this.alert = alert;
    }
}
