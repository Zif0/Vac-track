package database;

import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.ziapp.R;
import com.example.ziapp.UI.EditVacationActivity;
import com.example.ziapp.UI.MainActivity;
import database.entities.Vacation;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class VacationAdapter extends RecyclerView.Adapter<VacationAdapter.VacationViewHolder> {

    private List<Vacation> vacationList, filteredVacationList;
    private Set<Integer> selectedPositions = new HashSet<>();
    private boolean selectMode = false;
    private MainActivity mainActivity;
    private ActivityResultLauncher<Intent> vacationLauncher;

    public VacationAdapter(MainActivity mainActivity, List<Vacation> filteredVacationList, List<Vacation> vacationList, ActivityResultLauncher<Intent> vacationLauncher) {
        this.vacationList = vacationList;
        this.filteredVacationList = filteredVacationList;
        this.mainActivity = mainActivity;
        this.vacationLauncher = vacationLauncher;
    }

    @NonNull
    @Override
    public VacationViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_vacation, parent, false);
        return new VacationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(VacationViewHolder holder, int position) {
        Vacation vacation = vacationList.get(position);

        holder.title.setText(vacation.getTitle());
        holder.accommodation.setText(vacation.getAccommodation());
        holder.startDate.setText(vacation.getStartDate());
        holder.endDate.setText(vacation.getEndDate());

        holder.itemView.setBackgroundColor(selectedPositions.contains(position) ? Color.LTGRAY : Color.WHITE);

        holder.itemView.setOnLongClickListener(v -> {
            if (!selectMode) {
                selectMode = true;
                selectedPositions.clear();
                notifySelectMode();
                notifyDataSetChanged();
            }
            return true;
        });

        holder.itemView.setOnClickListener(v -> {
            if (selectMode) {
                toggleSelection(position);
            } else {
                Intent intent = new Intent(v.getContext(), EditVacationActivity.class);
                intent.putExtra("VACATION_ID", vacation.getId());
                vacationLauncher.launch(intent);
            }
        });
    }

    private void toggleSelection(int position) {
        if (selectedPositions.contains(position)) {
            selectedPositions.remove(position);
        } else {
            selectedPositions.add(position);
        }
        notifyDataSetChanged();

        if (selectedPositions.isEmpty()) {
            notifySelectMode();
        }
    }

    private void notifySelectMode() {
        if (mainActivity != null) {
            mainActivity.enterSelectMode();
        }
    }

    public boolean isSelectMode() {
        return selectMode;
    }

    public void resetSelectMode() {
        selectMode = false;
        selectedPositions.clear();
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return vacationList.size();
    }

    public static class VacationViewHolder extends RecyclerView.ViewHolder {

        TextView title, accommodation, startDate, endDate;

        public VacationViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.titleText);
            accommodation = itemView.findViewById(R.id.accommodationText);
            startDate = itemView.findViewById(R.id.startDateText);
            endDate = itemView.findViewById(R.id.endDateText);
        }
    }

    public List<Vacation> getSelectedVacations() {
        List<Vacation> selectedVacations = new ArrayList<>();
        for (int position : selectedPositions) {
            if (position >= 0 && position < vacationList.size()) {
                selectedVacations.add(vacationList.get(position));
            }
        }
        return selectedVacations;
    }
}
