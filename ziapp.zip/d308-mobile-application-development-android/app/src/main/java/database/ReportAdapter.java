package database;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.ziapp.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import database.entities.Vacation;

public class ReportAdapter extends RecyclerView.Adapter<ReportAdapter.ReportViewHolder> {

    private final List<Vacation> vacations;
    private final AppDatabase db;

    public ReportAdapter(List<Vacation> vacations, AppDatabase db) {
        this.vacations = vacations;
        this.db = db;
    }

    @Override
    public ReportViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_report, parent, false);
        return new ReportViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ReportViewHolder holder, int position) {
        Vacation vacation = vacations.get(position);
        holder.title.setText(vacation.getTitle());
        holder.accommodation.setText(vacation.getAccommodation());
        holder.start.setText(vacation.getStartDate());
        holder.end.setText(vacation.getEndDate());

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.US);
            Date start = sdf.parse(vacation.getStartDate());
            Date end = sdf.parse(vacation.getEndDate());

            if (start != null && end != null) {
                long duration = (end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24);
                holder.days.setText(String.valueOf(duration + 1)); // Inclusive
            } else {
                holder.days.setText("N/A");
            }
        } catch (ParseException e) {
            holder.days.setText("Err");
        }

        new Thread(() -> {
            int count = db.excursionDao().getExcursionsByVacationId(vacation.getId()).size();
            holder.itemView.post(() -> holder.excursionCount.setText(String.valueOf(count)));
        }).start();
    }

    @Override
    public int getItemCount() {
        return vacations.size();
    }

    static class ReportViewHolder extends RecyclerView.ViewHolder {
        TextView title, accommodation, start, end, days, excursionCount;

        public ReportViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.reportTitle);
            accommodation = itemView.findViewById(R.id.reportAccommodation);
            start = itemView.findViewById(R.id.reportStart);
            end = itemView.findViewById(R.id.reportEnd);
            days = itemView.findViewById(R.id.reportDays);
            excursionCount = itemView.findViewById(R.id.reportExcursionCount);
        }
    }
}
