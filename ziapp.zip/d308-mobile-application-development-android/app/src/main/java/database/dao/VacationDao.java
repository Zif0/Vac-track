package database.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import database.entities.Vacation;
@Dao
public interface VacationDao {
        @Insert
        void insertv(Vacation vacation);

        @Update
        void updatev(Vacation vacation);

        @Delete
        void deletev(Vacation vacation);

        @Query("SELECT COUNT(*) FROM excursions WHERE vacationId = :vacationId")
        int countExcursions(int vacationId);

        @Query("SELECT * FROM vacations WHERE id = :vacationId LIMIT 1")
        Vacation getVacationById(int vacationId);

        @Query("SELECT * FROM vacations")
        List<Vacation> getAllVacations();

}
