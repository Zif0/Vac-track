package database.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import database.entities.Excursion;

@Dao
public interface ExcursionDao {
    @Insert
    void insertE(Excursion excursion);

    @Update
    void updateE(Excursion excursion);

    @Delete
    void deleteE(Excursion excursion);

    @Query("SELECT * FROM excursions")
    List<Excursion> getAllExcursions();

    @Query("SELECT * FROM excursions WHERE vacationId = :vacationId")
    List<Excursion> getExcursionsByVacationId(int vacationId);

    @Query("SELECT * FROM excursions WHERE Id = :Id")
    Excursion getExcursionById(int Id);
}
